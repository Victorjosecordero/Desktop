document.addEventListener("DOMContentLoaded", () => {

    const toma = new XMLHttpRequest();
    toma.open("GET", "data/mascotas.json");
    toma.send();
    toma.responseType = "json";

    toma.addEventListener("load", () => {

        if (toma.readyState == 4 && toma.status == 200) {
            const datos = toma.response;
            var usuarios = document.getElementById("usuarios")
            var incluir = ''
            for (var dato of datos){
                
                incluir += '<div class="accordion-item">';
                incluir += '<h2 class="accordion-header">';
                incluir += '<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse' + dato.id + '" aria-expanded="true" aria-controls="collapse' + dato.id + '">';
                incluir += dato.pertenencia;
                incluir += '</button>';
                incluir += '</h2>';
                incluir += '<div id="collapse' + dato.id + '" class="accordion-collapse collapse" data-bs-parent="#accordionExample"><div class="accordion-body"><div class="card" ><img src="..." class="card-img-top" alt="..."><div class="card-body"><h5 class="card-title">Card title</h5><p class="card-text">Some quick example text to build on the card title and make up the bulk of the cards content.</p><a href="#" class="btn btn-primary">Go somewhere</a></div></div></div></div>';
                incluir += '</div>';

                usuarios.innerHTML = incluir;
  





            }
        

        } else {
            console.log("Hubo un error inesperado.")
        }

    })






});