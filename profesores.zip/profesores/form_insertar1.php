<?php include_once "template/header.php" ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <hr>
            <a class="btn btn-secondary" href="leerTabla.php">Visualizar</a>


            <hr>
            <h2 class="mt-4">Insertar alumnos</h2>
            <hr>
            <form method="post" action="accForm_insertar1.php">
                <div class="form-group">
                    <label for="nombre">Nombre</label>
                    <input type="text" name="nombre" id="nombre" class="form-control">
                </div>
                <div class="form-group">
                    <label for="apellido">Apellido</label>
                    <input type="text" name="apellido" id="apellido" class="form-control">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" class="form-control">
                </div>
                <div class="form-group">
                    <label for="telefono">Teléfono</label>
                    <input type="text" name="telefono" id="telefono" class="form-control">
                </div>
                <div class="form-group">
                    <label for="sueldo">Sueldo</label>
                    <input type="text" name="sueldo" id="sueldo" class="form-control">
                </div>
                <div class="form-group justify-content-md-end mt-3">
                    <input id="enviar" type="submit" name="submit" class="btn btn-outline-primary" value="Enviar" >
                </div>
            </form>
        </div>
    </div>
</div>

<?php include_once "template/footer.php" ?>
