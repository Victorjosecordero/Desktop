<?php

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0",false);
header("Pragma: no-cache");

?>

<?php include "template/header.php"; ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <hr>
            <a class="btn btn-secondary" href="form_insertar1.php">Ir al Formulario</a>
            <a class="btn btn-secondary" href="leerTabla.php">Visualizar Alumnos</a>
            <a class="btn btn-secondary" href="registros_borrar.php" >Ir a borrar registros</a>
            <a class="btn btn-secondary" href="modificar.php" >Ir a modificar alumnos</a>

            <hr>
        </div>
    </div>
</div>



<div class="container">
    <div class="row">
        <div class="col-md-12">
            <hr>
            <h2 class="mt-3">Registro modificar</h2>
            <hr>

<?php 

header("Content-Type: text/html;charset=utf-8");
include_once "FuncionesConex/funcionesConexion.php" ;

if(isset($_POST['btModificar']) && (!empty($_POST['modificar']))){

    $modificar=$_POST['modificar'];

    $conexion=conectar();
    if($conexion){
        mysqli_set_charset($conexion,'utf8');


        $query ="SELECT * FROM alumnos where id ='$modificar'";
    
        $consulta=mysqli_query($conexion, $query);

        if($consulta){
            $linea = mysqli_fetch_array($consulta, MYSQLI_ASSOC);
               
            print("<form method='post' action='validar_formmodificar.php'>");

                echo '<input id="pasoId" name="pasoId" type="hidden"  value="'. $linea["id"] .'" >';

                echo '<div class="form-group">
                    <label for="nombre">Nombre</label>';

                echo '<input type="text" name="nombre" id="nombre" value="'. $linea["nombre"] .'" class="form-control" pattern="^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]{3,30}*$" required>
                </div>';

                echo '<div class="form-group">
                    <label for="apellido">Apellido</label>
                    <input type="text" name="apellido" id="apellido" value="'. $linea["apellido"] .'" class="form-control"  pattern="^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]{3,30}*$" required>
                </div>';


                echo '<div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" value="'. $linea["email"] .'" class="form-control">
                </div>';

                echo '<div class="form-group">
                    <label for="telefono">Teléfono</label>
                    <input type="text" name="telefono" id="telefono"  value="'. $linea["telefono"] .'" class="form-control">
                </div>';
                echo '<div class="form-group justify-content-md-end mt-3">
                    <input id="enviar" type="submit" name="finModificar" class="btn btn-outline-primary" value="Modificar Datos" >
                </div>
            </form>';

        }

        desconectar($conexion);
    }else{
        $resultado =true;
        $mensaje="hay algun problema al conectar al BD <br>";
        mysqli_connect_error();
    }

}else{
    $resultado=true;
    $mensaje="NO HA SELECIONADO REGISTROS A MODIFICAR";
}
?>


<?php 
    if(isset($resultado)){

?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <div class="alert alert-danger" role="alert">
                <?= $mensaje ?>
            </div>
        </div>
    </div>
</div>
<?php 
    }
?>

    </div>
    </div>
</div>





<?php include_once "template/footer.php" ?>