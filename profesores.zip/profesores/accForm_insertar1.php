<?php

header("Content-Type: text/html;charset=utf-8");
include_once "FuncionesConex/funciones.php" ;
include_once "FuncionesConex/funcionesConexion.php" ;
?>

<?php include_once "template/header.php" ;?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <hr>
            <a class="btn btn-secondary" href="leerTabla.php" >Visualizar profesores </a>
            <a class="btn btn-secondary" href="form_insertar1.php" >Añadir mas profesores </a>

            <hr>
        </div>
    </div>
</div>



<?php
if($_SERVER["REQUEST_METHOD"]=="POST"){
    //VARIABLES
    $errores=array();
    $nombre= filtrado($_POST["nombre"]);
    $apellido= filtrado($_POST["apellido"]);
    $email = filtrado($_POST["email"]);
    $telefono = filtrado($_POST["telefono"]);
    $sueldo = filtrado($_POST["sueldo"]);


    if(empty($nombre) || (!preg_match("/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]*$/",$nombre)) || (strlen($nombre) < 3) ||(strlen($nombre)>30)){
        $errores[]="El nombre es requerido y su formato debe ser válido"; 
    }


    if(empty($errores)){
        $conexion = conectar();
        if($conexion){
            mysqli_set_charset($conexion, 'utf8');
            try{
                $stmt = mysqli_prepare($conexion,"INSERT INTO profesores(nombre,apellidos,email,telefono,sueldo) VALUES (?, ?, ?, ?, ?)");

                mysqli_stmt_bind_param($stmt, "sssid", $varNombre, $varApellido, $varEmail, $varTelefono, $varSueldo);

                $varNombre = $nombre;
                $varApellido = $apellido;
                $varEmail = $email;
                $varTelefono = $telefono;
                $varSueldo = $sueldo;

                mysqli_stmt_execute($stmt);

                mysqli_stmt_close($stmt);
                $resultado = true;
                $mensaje="PROFESOR INSERTADO EN LA BASE DE DATOS";
            }
            catch(mysqli_sql_exception $e){
                $resultado = false;
                $mensaje="Ha habido una excepción: ". mysqli_connect_error() . mysqli_connect_errno();
                echo $mensaje;
            }
            desconectar($conexion);

        }
    }
    
}
if(isset($resultado)){
    ?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-<?= $resultado ? 'success' : 'danger' ?>" role='alert'>
                <?= $mensaje?>
                </div>
            </div>
        </div>
    </div>
    <?php
        }
    ?>
