<?php include_once "template/header.php" ;?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <hr>
            <a class="btn btn-secondary" href="form_insertar1.php">Ir al Formulario</a>
            <a class="btn btn-secondary" href="leerTabla.php">Visualizar Alumnos</a>
            <a class="btn btn-secondary" href="modificar.php" >Ir a modificar alumnos</a>
            
            <hr>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <hr>
            <h2 class="mt-3">Eliminar Alumnos</h2>
            <hr>


<?php 

header("Content-Type: text/html;charset=utf-8");
include_once "FuncionesConex/funcionesConexion.php" ;


$conexion=conectar();
if($conexion){
    mysqli_set_charset($conexion,'utf8');
    try {
        $query= "SELECT * FROM alumnos";
        $resul=mysqli_query($conexion, $query);

        print("<form action='mostrar_borrado.php' method='post' autocomplete='off'>");
        consultaConTablaBorrar($resul);

        print("<button type='submit' class='btn btn-primary' name='eliminar'> Eliminar Alumnos Seleccionados</button>");
        print("</form>");


        mysqli_free_result($resul);
        
    } catch (mysqli_sql_exception $e) {
        $resultado =true;
        $mensaje="hay algun problema al ejecutar la sentencia de lectura a la tabla de BD <br>" . $e->getMessage() . mysqli_connect_error() . mysqli_connect_errno();
        mysqli_connect_error();
    }

    desconectar($conexion);

}else{
    $resultado =true;
    $mensaje="hay algun problema al conectar al BD <br>";
    mysqli_connect_error();
}

?>


<?php 
    if(isset($resultado)){

?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <div class="alert alert-danger" role="alert">
                <?= $mensaje ?>
            </div>
        </div>
    </div>
</div>
<?php 
    }
?>

    </div>
    </div>
</div>





<?php include_once "template/footer.php" ?>