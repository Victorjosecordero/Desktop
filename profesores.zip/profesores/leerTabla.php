<?php include_once "template/header.php" ;?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <hr>
            <a class="btn btn-secondary" href="form_insertar1.php">Añadir Profesores</a>

            <hr>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <hr>
            <h2 class="mt-3">Visualizar Profesores</h2>
            <hr>


<?php 

header("Content-Type: text/html;charset=utf-8");
include_once "FuncionesConex/funcionesConexion.php" ;


$conexion=conectar();
if($conexion){
    try {
        mysqli_set_charset($conexion,'utf8');
        $query= "SELECT * FROM profesores";
        $resul=mysqli_query($conexion, $query);

        print("<form action='modYBorrar.php' method='post' autocomplete='off'>");
       
        consultaConTabla($resul);

       
        mysqli_free_result($resul);
        
    } catch (mysqli_sql_exception $e) {
        $resultado =true;
        $mensaje="hay algun problema al ejecutar la sentencia de lectura a la tabla de BD <br>" . $e->getMessage() . mysqli_connect_error() . mysqli_connect_errno();
        mysqli_connect_error();
    }

    desconectar($conexion);

}else{
    $resultado =true;
    $mensaje="hay algun problema al conectar al BD <br>";
    mysqli_connect_error();
}

?>


<?php 
    if(isset($resultado)){

?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <div class="alert alert-danger" role="alert">
                <?= $mensaje ?>
            </div>
        </div>
    </div>
</div>
<?php 
    }
?>

    </div>
    </div>
</div>