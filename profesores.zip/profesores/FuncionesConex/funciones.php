<?php
//FUNCIONES
function filtrado($datos){
    $datos=trim($datos);
    $datos=stripslashes($datos);
    $datos=htmlspecialchars($datos);
    return $datos;
}//Cierra funcion 
?>