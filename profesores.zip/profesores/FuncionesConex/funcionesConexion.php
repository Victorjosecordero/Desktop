<?php 

include_once "FuncionesConex/funciones.php" ;
?>


<?php
   // conectar();
    function conectar(){
        $host = "localhost";
        $usuario="root";
        $pw="1234";
        $BDconex = "practica_cole";
        

        try{
            $db = mysqli_connect($host,$usuario, $pw, $BDconex);;
        }catch(mysqli_sql_exception $e){
            echo "<p>Ha habido una excepción: ". $e->getMessage() .  mysqli_connect_errno() .  mysqli_connect_error() ."</p>";
            $db = false;
        }

        return $db;
    }
    function desconectar($conexion){
        $desconectar = mysqli_close($conexion);

        if(!$desconectar){
            echo "<p>Error en la desconexion ". mysqli_connect_error()."</p>";
        }
    }

    //leer cualquier tabla

    function consultaConTabla($resul){
  
        print("<form action='mostrar_borrado.php' method='post' autocomplete='off'>");


        echo "<table class='table table-bordered table-striped table-hover text-center'>";

            echo "<thead>";

                echo "<tr>";

                    while($finfo = mysqli_fetch_field($resul)){
                        echo "<th>";
                        echo    $finfo->name;
                        echo "</th>";
                    }
                    echo "<th>Modificar</th>";
                    echo "<th>Eliminar</th>";
                    
                    
                echo "</tr>";

            echo "</thead>";

            echo "<tbody>";

                while($linea = mysqli_fetch_array($resul, MYSQLI_ASSOC)){
                    echo "<tr>";
                      

                        foreach($linea as $col_valor){
                            echo "<td> $col_valor </td>";
                        }

                        print("<td class='text-center'><button style='border:none;' type='submit' name='modificar' value='" .  $linea['id'] .  "' ><img class='botones' src='img/editar.png'></button></td>");
                        print("<td class='text-center'><button style='border:none;' type='submit' name='borrar' value='" .  $linea['id'] .  "' ><img class='botones' src='img/borrar.png'></button></td>");
                    
                    echo "</tr>";
                }
                

            echo "</tbody>";
        
        echo "</table>";
   
    }

    function consultaConTablaBorrar($resul){
  

        echo "<table class='table table-bordered table-striped table-hover'>";

            echo "<thead>";

                echo "<tr>";

                    while($finfo = mysqli_fetch_field($resul)){
                        echo "<th>";
                        echo    $finfo->name;
                        echo "</th>";
                
                    }
                    echo "<th>Modificar</th>";
                    echo "<th>Eliminar</th>";
                echo "</tr>";

            echo "</thead>";

            echo "<tbody>";

                while($linea = mysqli_fetch_array($resul, MYSQLI_ASSOC)){
                    echo "<tr>";

                        foreach($linea as $col_valor){
                            echo "<td> $col_valor </td>";
                        }
                        print("<td class='text-center'><button style='border:none;' type='submit' name='modificar' value='" .  $linea['id'] .  "' ><img class='botones' src='img/editar.png'></button></td>");
                        print("<td class='text-center'><button style='border:none;' type='submit' name='borrar' value='" .  $linea['id'] .  "' ><img class='botones' src='img/borrar.png'></button></td>");
                    
                    echo "</tr>";
                }

            echo "</tbody>";
        
        echo "</table>";
   
    }




    function borrarYcrearListaBorrado($conexion,$borrar){
        $nfilas=count($borrar);

        //obtengo los datos de los alumnos eliminados y seguidamente
        for($i=0; $i< count($borrar); $i++){

            $query = "SELECT * FROM alumnos where id = $borrar[$i]";
            $consulta = mysqli_query($conexion,$query);
            $resultado = mysqli_fetch_array($consulta,  MYSQLI_ASSOC);

            print("<ul class='list-group'>");
            print("<li class='list-group-item active' aria-current='true'> ID:" . $resultado['id'] . "</li>");
            print("<li class='list-group-item'>Nombre:" . $resultado['nombre'] . "</li>");
            print("<li class='list-group-item'>Apellido:" . $resultado['apellido'] . "</li>");
            print("<li class='list-group-item'>Correo:" . $resultado['email'] . "</li>");
            print("<li class='list-group-item'>Teléfono:" . $resultado['telefono'] . "</li>");
            print("</ul>");


            //borramos los registros de la BD

            $eliminacion ="DELETE FROM alumnos where id = $borrar[$i]";

            $consulta2 =  mysqli_query($conexion,$eliminacion);

            if(!$consulta2){
                print("<hr><div class='alert alert-danger' role='alert'>Error al eliminar el registro</div>");
                $nfilas--;
            }

        }
        print("<hr><div class='alert alert-danger' role='alert'>Numero total de registos borrados: " . $nfilas . "</div>");

    }


    function modificarTabla($resul){
  

        echo "<table class='table table-bordered table-striped table-hover'>";

            echo "<thead>";

                echo "<tr>";

                    while($finfo = mysqli_fetch_field($resul)){
                        echo "<th>";
                        echo    $finfo->name;
                        echo "</th>";

                
                    }
                    echo "<th>Modificar</th>";
                echo "</tr>";

            echo "</thead>";

            echo "<tbody>";

                while($linea = mysqli_fetch_array($resul, MYSQLI_ASSOC)){
                    echo "<tr>";

                        foreach($linea as $col_valor){
                            echo "<td> $col_valor </td>";
                        }
                        print("<td><input class='radioBtn' type='radio' name='modificar' value='" .  $linea['id'] .  "' ></td>");
                    
                    echo "</tr>";
                }

            echo "</tbody>";
        
        echo "</table>";
   
    }



   /* function modificarProfesor(){
        $errores=array();
    $id= filtrado($_POST["pasoId"]);
    $nombre= filtrado($_POST["nombre"]);
    $apellido= filtrado($_POST["apellido"]);
    $email = filtrado($_POST["email"]);
    $telefono = filtrado($_POST["telefono"]);


    if(empty($nombre) || (!preg_match("/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]*$/",$nombre)) || (strlen($nombre) < 3) ||(strlen($nombre)>30)){
        $errores[]="El nombre es requerido y su formato debe ser válido"; 
    }

    if(empty($apellido) || (!preg_match("/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]*$/",$apellido)) || (strlen($apellido) < 3) ||(strlen($apellido)>30)){
        $errores[]="El apellido es requerido y su formato debe ser válido"; 
    }

    /*if(empty($email) || (!preg_match("/^\A[A-Z0-9+_.-]+@[A-Z0-9.-]+\Z*$/",$email)) || (strlen($email) < 3) ||(strlen($email)>30)){
        $errores[]="El email es requerido y su formato debe ser válido"; 
    }


    if(empty($errores)){
        $conexion = conectar();
        if($conexion){
            mysqli_set_charset($conexion, 'utf8');
            try{
                $stmt = mysqli_prepare($conexion,"UPDATE alumnos SET nombre=?, apellido=?, email=? ,telefono=? WHERE id=$id");

                mysqli_stmt_bind_param($stmt, "sssi", $varNombre, $varApellido, $varEmail, $varTelefono);

                $varNombre = $nombre;
                $varApellido = $apellido;
                $varEmail = $email;
                $varTelefono = $telefono;

                mysqli_stmt_execute($stmt);

                mysqli_stmt_close($stmt);

                $resultado = true;
                $mensaje="ALUMNO MODIFICADO EN LA BASE DE DATOS";
            }
            catch(mysqli_sql_exception $e){
                $resultado = false;
                $mensaje="Ha habido una excepción: ". mysqli_connect_error() . mysqli_connect_errno();
                echo $mensaje;
            }
            desconectar($conexion);

        }else{
            echo "<ul>";
            foreach($errores as $e){
                echo "<li> $e </li>";
            }
            echo "</ul>";
        }
    }
}*/
    
function borrarProfesor(){
    $borrar=$_POST['borrar'];


    //obtengo los datos de los alumnos eliminados y seguidamente
    

        $query = "SELECT * FROM profesores where id = $borrar";
        $consulta = mysqli_query($conexion,$query);
        $resultado = mysqli_fetch_array($consulta,  MYSQLI_ASSOC);

        print("<ul class='list-group'>");
        print("<li class='list-group-item active' aria-current='true'> ID:" . $resultado['id'] . "</li>");
        print("<li class='list-group-item'>Nombre:" . $resultado['nombre'] . "</li>");
        print("<li class='list-group-item'>Apellido:" . $resultado['apellido'] . "</li>");
        print("<li class='list-group-item'>Correo:" . $resultado['email'] . "</li>");
        print("<li class='list-group-item'>Teléfono:" . $resultado['telefono'] . "</li>");
        print("<li class='list-group-item'>Sueldo:" . $resultado['sueldo'] . "</li>");
        print("</ul>");


        //borramos los registros de la BD

        $eliminacion ="DELETE FROM profesores where id = $borrar";

        $consulta2 =  mysqli_query($conexion,$eliminacion);

        if(!$consulta2){
            print("<hr><div class='alert alert-danger' role='alert'>Error al eliminar el registro</div>");
            $nfilas--;
        }

    }



?>