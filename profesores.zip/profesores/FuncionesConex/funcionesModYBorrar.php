<?php

function modificarProfesores(){
    $conexion=conectar();
    if($conexion){
        mysqli_set_charset($conexion,'utf8');
        $modificar=$_POST['modificar'];



        $query ="SELECT * FROM profesores where id ='$modificar'";
    
        $consulta=mysqli_query($conexion, $query);

        if($consulta){
            $linea = mysqli_fetch_array($consulta, MYSQLI_ASSOC);
               
            print("<form method='post' action='validar_formmodificar.php'>");

                echo '<input id="pasoId" name="pasoId" type="hidden"  value="'. $linea["id"] .'" >';

                echo '<div class="form-group">
                    <label for="nombre">Nombre</label>';

                echo '<input type="text" name="nombre" id="nombre" value="'. $linea["nombre"] .'" class="form-control" pattern="^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]{3,30}*$" required>
                </div>';

                echo '<div class="form-group">
                    <label for="apellido">Apellido</label>
                    <input type="text" name="apellido" id="apellido" value="'. $linea["apellidos"] .'" class="form-control"  pattern="^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]{3,30}*$" required>
                </div>';


                echo '<div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" value="'. $linea["email"] .'" class="form-control">
                </div>';

                echo '<div class="form-group">
                    <label for="telefono">Teléfono</label>
                    <input type="text" name="telefono" id="telefono"  value="'. $linea["telefono"] .'" class="form-control">
                </div>';

                echo '<div class="form-group">
                    <label for="sueldo">Sueldo</label>
                    <input type="text" name="sueldo" id="sueldo"  value="'. $linea["sueldo"] .'" class="form-control">
                </div>';
                echo '<div class="form-group justify-content-md-end mt-3">
                    <input id="enviar" type="submit" name="finModificar" class="btn btn-outline-primary" value="Modificar Datos" >
                </div>
            </form>';

        }

        desconectar($conexion);
    }else{
    $resultado =true;
    $mensaje="hay algun problema al conectar al BD <br>";
    mysqli_connect_error();
    }
}

function eliminarProfresor(){


    $conexion=conectar();
    if($conexion){
        mysqli_set_charset($conexion,'utf8');
    
        $borrar=$_POST['borrar'];


    //obtengo los datos de los alumnos eliminados y seguidamente
    

        $query = "SELECT * FROM profesores where id = $borrar";
        $consulta = mysqli_query($conexion,$query);
        $resultado = mysqli_fetch_array($consulta,  MYSQLI_ASSOC);

        print("<ul class='list-group'>");
        print("<li class='list-group-item active' aria-current='true'> ID:" . $resultado['id'] . "</li>");
        print("<li class='list-group-item'>Nombre:" . $resultado['nombre'] . "</li>");
        print("<li class='list-group-item'>Apellido:" . $resultado['apellidos'] . "</li>");
        print("<li class='list-group-item'>Correo:" . $resultado['email'] . "</li>");
        print("<li class='list-group-item'>Teléfono:" . $resultado['telefono'] . "</li>");
        print("<li class='list-group-item'>Sueldo:" . $resultado['sueldo'] . "</li>");
        print("</ul>");


        //borramos los registros de la BD

        $eliminacion ="DELETE FROM profesores where id = $borrar";

        $consulta2 =  mysqli_query($conexion,$eliminacion);

        if(!$consulta2){
            print("<hr><div class='alert alert-danger' role='alert'>Error al eliminar el registro</div>");
        
        }else{
            print("<hr><div class='alert alert-success' role='alert'>Eliminado Correctamente</div>");
        }


        desconectar($conexion);

    }else{
        $resultado =true;
        $mensaje="hay algun problema al conectar al BD <br>";
        mysqli_connect_error();
    }
  
        
}
?>
